function loadTable(tableId, columns, url, visible ) {
	var table = $('#'+tableId).DataTable( {
		"scrollX": false,
		responsive: true,
        "columnDefs": [
            {
                "targets": [ 0 ],
                "visible": visible
            }
        ],
        columns: columns,
        "ajax": {
            "url": url,
            "processing": true,
            "dataSrc": function(json){
            	console.log(json);
            	if(json === undefined || json === "" || json === null || json.length === 0) {
            		return [];
            	} else if(json.hasOwnProperty("success") && json.success === false) {
            		return [];
            	}
            	
            	console.log(json);
            	
            	return json;
            }
        }
    } );
	
	return table;
}

function adjustDataTableUI(table) {
	setTimeout(function(){
		dataTable.columns.adjust().draw(false);
		dataTable.responsive.recalc();
	}, 500);
}