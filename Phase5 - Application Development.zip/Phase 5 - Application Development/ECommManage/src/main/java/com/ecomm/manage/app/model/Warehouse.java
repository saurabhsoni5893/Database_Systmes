package com.ecomm.manage.app.model;

import java.io.Serializable;

public class Warehouse implements Serializable {

	private static final long serialVersionUID = 1L;
	int warehouseId;
	String City;
	String State;
	int capacity;

	public int getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(int warehouseId) {
		this.warehouseId = warehouseId;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

}
