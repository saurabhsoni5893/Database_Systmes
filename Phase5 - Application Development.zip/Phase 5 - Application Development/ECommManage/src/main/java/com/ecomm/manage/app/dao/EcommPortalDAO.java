package com.ecomm.manage.app.dao;

import java.util.List;

import com.ecomm.manage.app.model.EcommPortal;

public interface EcommPortalDAO {
	public int addEcommPortal(EcommPortal ecommPortal);

//	public void updateEcommPortal(EcommPortal ecommPortal);
//	public void deleteEcommPortal(int portalId);
//	public EcommPortal getEcommPortalById(int portalId);

	public List<EcommPortal> getEcommPortals();
}
