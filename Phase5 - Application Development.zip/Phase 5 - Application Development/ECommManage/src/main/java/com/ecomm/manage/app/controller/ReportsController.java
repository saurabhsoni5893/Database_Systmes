package com.ecomm.manage.app.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecomm.manage.app.model.Product;
import com.ecomm.manage.app.services.ProductService;
import com.ecomm.manage.app.services.ProductServiceImpl;
import com.google.gson.Gson;

public class ReportsController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String filter = req.getParameter("filter");
		String startDate = req.getParameter("startDate");
		String endDate = req.getParameter("endDate");

		resp.setContentType("application/json");

		ProductService productService = new ProductServiceImpl();
		if ((startDate != null) && (endDate != null) && (startDate != "") && (endDate != "")) {
			if ("productsSoldTheMost".equals(filter)) {
				List<Product> productList = productService.findProductsSoldTheMost(startDate, endDate);
				resp.getWriter().write(new Gson().toJson(productList));
			} else if ("productsSoldTheLeast".equals(filter)) {
				List<Product> productList = productService.findProductsSoldTheLeast(startDate, endDate);
				resp.getWriter().write(new Gson().toJson(productList));
			} else if ("productsReturnedTheMost".equals(filter)) {
				List<Product> productList = productService.findProductsReturnedTheMost(startDate, endDate);
				resp.getWriter().write(new Gson().toJson(productList));
			} else if ("productsReturnedTheLeast".equals(filter)) {
				List<Product> productList = productService.findProductsReturnedTheLeast(startDate, endDate);
				resp.getWriter().write(new Gson().toJson(productList));
			}
		} else {
			resp.getWriter().write(new Gson().toJson(new ArrayList<Product>()));
		}
	}
}
