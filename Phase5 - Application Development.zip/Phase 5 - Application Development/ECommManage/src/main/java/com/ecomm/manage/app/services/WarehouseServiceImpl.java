package com.ecomm.manage.app.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ecomm.manage.app.dao.WarehouseDAO;
import com.ecomm.manage.app.dao.WarehouseDAOImpl;
import com.ecomm.manage.app.model.Warehouse;

public class WarehouseServiceImpl implements WarehouseService {

	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(WarehouseServiceImpl.class.getName());

	WarehouseDAO warehouseDao;

	@Override
	public List<Warehouse> getWarehouses() {
		warehouseDao = getWarehouseDao();
		return warehouseDao.getWarehouses();
	}

	@Override
	public int deleteWarehouseById(int warehouseId) {
		warehouseDao = getWarehouseDao();
		return warehouseDao.deleteWarehouseById(warehouseId);
	}

	WarehouseDAO getWarehouseDao() {
		return new WarehouseDAOImpl();
	}
}
