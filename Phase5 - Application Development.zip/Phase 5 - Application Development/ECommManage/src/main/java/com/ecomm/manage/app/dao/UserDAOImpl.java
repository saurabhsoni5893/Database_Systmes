package com.ecomm.manage.app.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ecomm.manage.app.model.User;
import com.ecomm.manage.app.singleton.connection.DBConnect;

// TODO: Auto-generated Javadoc
/**
 * The Class UserDAOImpl.
 */
public class UserDAOImpl implements UserDAO {

	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(UserDAOImpl.class.getName());

	/*
	 * (non-Javadoc)
	 *
	 * @see com.springmvc.hibernate.training.project.dao.UserDAO#
	 * findUserByUsernamePassword(java.lang.String, java.lang.String)
	 */
	@Override
	public User findUserByUsernamePassword(String username, String password) {
		log.info("userDao : Executing findUserByUsernamePassword method");

		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.springmvc.hibernate.training.project.dao.UserDAO#
	 * findUserByEmailAddress(java.lang.String)
	 */
	@Override
	public User findUserByEmailAddress(String emailAddress) {
		log.info("userDao : Executing findUserByEmailAddress method");

		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.springmvc.hibernate.training.project.dao.UserDAO#updatePassword(java.
	 * lang.String, java.lang.String)
	 */
	@Override
	public int updatePassword(String emailAddress, String password) {
		log.info("userDao: Executing updatePassword method");

		return 0;
	}

	@Override
	public void updateUser(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<User> getUsers() {
		List<User> userList = new ArrayList<User>();
		ResultSet rs = DBConnect.getInstance().query("Select * from User");
		if (rs != null) {
			try {
				while (rs.next()) {
					User user = new User();
					user.setUserId(rs.getInt("userId"));
					user.setName(rs.getString("name"));
					user.setPassword(rs.getString("password"));
					user.setEmail(rs.getString("email"));

					userList.add(user);
				}
			} catch (SQLException e) {
				log.error("Exception while getting user list: ", e);
			}
		}
		return userList;
	}

	@Override
	public User findByUserId(long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteUser(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public int deleteUserById(long userId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub

	}

}
