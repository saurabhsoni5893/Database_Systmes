package com.ecomm.manage.app.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ecomm.manage.app.model.Warehouse;
import com.ecomm.manage.app.singleton.connection.DBConnect;

public class WarehouseDAOImpl implements WarehouseDAO {

	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(WarehouseDAOImpl.class.getName());

	@Override
	public List<Warehouse> getWarehouses() {
		List<Warehouse> warehouseList = new ArrayList<Warehouse>();
		ResultSet rs = DBConnect.getInstance().query("Select * from F18_23_WAREHOUSES");
		if (rs != null) {
			try {
				while (rs.next()) {
					Warehouse warehouse = new Warehouse();
					warehouse.setWarehouseId(rs.getInt("WAREHOUSE_ID"));
					warehouse.setState(rs.getString("STATE"));
					warehouse.setCity(rs.getString("CITY"));
					warehouse.setCapacity(rs.getInt("TOTAL_CAPACITY"));

					warehouseList.add(warehouse);
				}
			} catch (SQLException e) {
				log.error("Exception while getting warehouse list: ", e);
			}
		}
		return warehouseList;
	}

	@Override
	public int deleteWarehouseById(int warehouseId) {
		return DBConnect.getInstance()
				.InsertUpdateOrDelete("delete from F18_23_WAREHOUSES where WAREHOUSE_ID=" + warehouseId);
	}

}
