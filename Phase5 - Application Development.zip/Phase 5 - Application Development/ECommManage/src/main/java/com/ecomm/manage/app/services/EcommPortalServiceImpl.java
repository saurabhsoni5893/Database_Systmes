package com.ecomm.manage.app.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ecomm.manage.app.dao.EcommPortalDAO;
import com.ecomm.manage.app.dao.EcommPortalDAOImpl;
import com.ecomm.manage.app.model.EcommPortal;

public class EcommPortalServiceImpl implements EcommPortalService {

	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(EcommPortalServiceImpl.class.getName());

	/** The user dao. */
	private EcommPortalDAO ecommPortalDao;

	@Override
	public int addEcommPortal(EcommPortal ecommPortal) {
		ecommPortalDao = getEcommPortalDao();
		return ecommPortalDao.addEcommPortal(ecommPortal);
	}

	@Override
	public List<EcommPortal> getEcommPortals() {
		ecommPortalDao = getEcommPortalDao();
		return ecommPortalDao.getEcommPortals();
	}

	EcommPortalDAO getEcommPortalDao() {
		return new EcommPortalDAOImpl();
	}
}
