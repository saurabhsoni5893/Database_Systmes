package com.ecomm.manage.app.services;

import java.util.List;

import com.ecomm.manage.app.model.Supplier;

public interface SupplierService {
	public List<Supplier> getSuppliers();

	public List<Supplier> getSuppliersByType(String types);
}
