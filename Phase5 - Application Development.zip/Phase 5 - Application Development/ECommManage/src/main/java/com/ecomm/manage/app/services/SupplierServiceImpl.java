package com.ecomm.manage.app.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ecomm.manage.app.dao.SupplierDAO;
import com.ecomm.manage.app.dao.SupplierDAOImpl;
import com.ecomm.manage.app.model.Supplier;

public class SupplierServiceImpl implements SupplierService {

	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(SupplierServiceImpl.class.getName());

	SupplierDAO supplierDao;

	@Override
	public List<Supplier> getSuppliers() {
		supplierDao = getSupplierDao();
		return supplierDao.getSuppliers();
	}

	@Override
	public List<Supplier> getSuppliersByType(String types) {
		supplierDao = getSupplierDao();
		return supplierDao.getSuppliersByType(types);
	}

	public SupplierDAO getSupplierDao() {
		return new SupplierDAOImpl();
	}

}
