package com.ecomm.manage.app.dao;

import java.util.List;

import com.ecomm.manage.app.model.Warehouse;

public interface WarehouseDAO {
	public List<Warehouse> getWarehouses();

	public int deleteWarehouseById(int warehouseId);

}
