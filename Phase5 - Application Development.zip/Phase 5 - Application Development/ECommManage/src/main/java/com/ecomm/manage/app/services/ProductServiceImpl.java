package com.ecomm.manage.app.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ecomm.manage.app.dao.ProductDAO;
import com.ecomm.manage.app.dao.ProductDAOImpl;
import com.ecomm.manage.app.model.Product;

public class ProductServiceImpl implements ProductService {

	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(ProductServiceImpl.class.getName());

	ProductDAO productDao;

	@Override
	public List<Product> getProducts() {
		productDao = getProductDao();
		return productDao.getProducts();
	}

	@Override
	public int deleteProductById(String productId) {
		productDao = getProductDao();
		return productDao.deleteProductById(productId);
	}

	@Override
	public List<Product> getProductsByWarehouseId(int warehouseId) {
		productDao = getProductDao();
		return productDao.getProductsByWarehouseId(warehouseId);
	}

	ProductDAO getProductDao() {
		return new ProductDAOImpl();
	}

	@Override
	public List<Product> findProductsSoldTheLeast(String startDate, String endDate) {
		productDao = getProductDao();
		return productDao.findProductsSoldTheLeast(startDate, endDate);
	}

	@Override
	public List<Product> findProductsReturnedTheMost(String startDate, String endDate) {
		productDao = getProductDao();
		return productDao.findProductsReturnedTheMost(startDate, endDate);
	}

	@Override
	public List<Product> findProductsReturnedTheLeast(String startDate, String endDate) {
		productDao = getProductDao();
		return productDao.findProductsReturnedTheLeast(startDate, endDate);
	}

	@Override
	public List<Product> findProductsSoldTheMost(String startDate, String endDate) {
		productDao = getProductDao();
		return productDao.findProductsSoldTheMost(startDate, endDate);
	}

}
