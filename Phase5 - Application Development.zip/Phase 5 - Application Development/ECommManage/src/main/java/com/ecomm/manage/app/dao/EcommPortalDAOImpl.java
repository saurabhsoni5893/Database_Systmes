package com.ecomm.manage.app.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ecomm.manage.app.model.EcommPortal;
import com.ecomm.manage.app.singleton.connection.DBConnect;

public class EcommPortalDAOImpl implements EcommPortalDAO {

	private static final AtomicInteger count = new AtomicInteger(0);
	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(EcommPortalDAOImpl.class.getName());

	@Override
	public int addEcommPortal(EcommPortal ecommPortal) {
		int totalRecords = getEcommPortals().size();
		if (totalRecords > count.get()) {
			count.set(count.get() + (totalRecords - count.get()));
		}

		String insertQuery = "insert into F18_23_ECOMM_PORTALS (PORTAL_ID, NAME, COUNTRY) values ("
				+ count.incrementAndGet() + ",\"" + ecommPortal.getName() + "\",\"" + ecommPortal.getCountry() + "\")";
		int success = DBConnect.getInstance().InsertUpdateOrDelete(insertQuery);
		return success;
	}

	@Override
	public List<EcommPortal> getEcommPortals() {
		List<EcommPortal> ecommPortalList = new ArrayList<EcommPortal>();
		ResultSet rs = DBConnect.getInstance().query("Select * from F18_23_ECOMM_PORTALS");
		if (rs != null) {
			try {
				while (rs.next()) {
					EcommPortal ecommPortal = new EcommPortal();
					ecommPortal.setPortalId(rs.getInt("PORTAL_ID"));
					ecommPortal.setName(rs.getString("NAME"));
					ecommPortal.setCountry(rs.getString("COUNTRY"));

					ecommPortalList.add(ecommPortal);
				}
			} catch (SQLException e) {
				log.error("Exception while getting ecommPortal list: ", e);
			}
		}
		return ecommPortalList;
	}
}
