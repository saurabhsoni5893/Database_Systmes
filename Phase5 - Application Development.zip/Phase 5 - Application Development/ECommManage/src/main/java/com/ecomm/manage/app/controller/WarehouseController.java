package com.ecomm.manage.app.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecomm.manage.app.model.Product;
import com.ecomm.manage.app.model.Warehouse;
import com.ecomm.manage.app.services.ProductService;
import com.ecomm.manage.app.services.ProductServiceImpl;
import com.ecomm.manage.app.services.WarehouseService;
import com.ecomm.manage.app.services.WarehouseServiceImpl;
import com.google.gson.Gson;

public class WarehouseController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String task = req.getParameter("task");

		WarehouseService warehouseService = new WarehouseServiceImpl();
		int success = 0;
		resp.setContentType("application/json");

		if ("delete".equals(task)) {
			int warehouseId = Integer
					.parseInt(req.getParameter("warehouseId") == null ? "0" : req.getParameter("warehouseId"));

			ProductService productService = new ProductServiceImpl();
			List<Product> productList = productService.getProductsByWarehouseId(warehouseId);
			if ((productList != null) && (productList.size() > 0)) {
				resp.getWriter().write(
						"{\"success\":false,\"message\":\"Please delete products from the warehouse first, Thank You.\"}");
			} else {
				success = warehouseService.deleteWarehouseById(warehouseId);
				if (success > 0) {
					resp.getWriter().write("{\"success\":true,\"message\":\"Warehouse successfully deleted.\"}");
				} else {
					resp.getWriter().write("{\"success\":false,\"message\":\"Something went wrong, try again!\"}");
				}
			}
		} else {
			List<Warehouse> warehouseList = warehouseService.getWarehouses();
			resp.getWriter().write(new Gson().toJson(warehouseList));
		}
	}
}
