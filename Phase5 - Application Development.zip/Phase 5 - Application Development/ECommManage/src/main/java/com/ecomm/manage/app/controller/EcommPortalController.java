package com.ecomm.manage.app.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecomm.manage.app.model.EcommPortal;
import com.ecomm.manage.app.services.EcommPortalService;
import com.ecomm.manage.app.services.EcommPortalServiceImpl;
import com.google.gson.Gson;

public class EcommPortalController extends HttpServlet {

	/**
	 * Default serial version UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		EcommPortalService ecommPortalService = new EcommPortalServiceImpl();
		List<EcommPortal> ecommPortalList = ecommPortalService.getEcommPortals();

		resp.setContentType("application/json");
		resp.getWriter().write(new Gson().toJson(ecommPortalList));
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("name");
		String country = req.getParameter("country");

		EcommPortalService ecommPortalService = new EcommPortalServiceImpl();
		EcommPortal ecommPortal = new EcommPortal();
		ecommPortal.setName(name);
		ecommPortal.setCountry(country);
		int success = ecommPortalService.addEcommPortal(ecommPortal);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/views/ecomm-portal.jsp");
		req.setAttribute("success", success);
		req.setAttribute("name", name);
		dispatcher.forward(req, resp);
		// resp.sendRedirect(req.getContextPath() + "/views/ecomm-portal.jsp?success=" +
		// success + "&name=" + name);
	}
}
