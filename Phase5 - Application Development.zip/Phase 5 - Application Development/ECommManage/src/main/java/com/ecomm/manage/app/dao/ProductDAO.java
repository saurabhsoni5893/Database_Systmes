package com.ecomm.manage.app.dao;

import java.util.List;

import com.ecomm.manage.app.model.Product;

public interface ProductDAO {
	public List<Product> getProducts();

	public int deleteProductById(String productId);

	public List<Product> getProductsByWarehouseId(int warehouseId);

	public List<Product> findProductsSoldTheMost(String startDate, String endDate);

	public List<Product> findProductsSoldTheLeast(String startDate, String endDate);

	public List<Product> findProductsReturnedTheMost(String startDate, String endDate);

	public List<Product> findProductsReturnedTheLeast(String startDate, String endDate);
}
