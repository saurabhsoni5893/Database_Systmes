package com.ecomm.manage.app.services;

import java.util.List;

import com.ecomm.manage.app.model.Warehouse;

public interface WarehouseService {
	public List<Warehouse> getWarehouses();

	public int deleteWarehouseById(int warehouseId);
}
