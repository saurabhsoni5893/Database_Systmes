package com.ecomm.manage.app.model;

import java.io.Serializable;

public class EcommPortal implements Serializable {
	private static final long serialVersionUID = 1L;
	int portalId;
	String name;
	String Country;

	public int getPortalId() {
		return portalId;
	}

	public void setPortalId(int portalId) {
		this.portalId = portalId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		Country = country;
	}

}
