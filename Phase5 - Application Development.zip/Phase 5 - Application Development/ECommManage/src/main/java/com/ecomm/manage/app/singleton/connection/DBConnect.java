package com.ecomm.manage.app.singleton.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DBConnect {
	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(DBConnect.class.getName());

	private static DBConnect instance;
	private Connection con;
	private Statement statement;

	public DBConnect() {
		try {
			ResourceBundle bundle = ResourceBundle.getBundle("language");

			// Oracle
//			OracleDataSource oracledataSoruce = new OracleDataSource();
//			oracledataSoruce.setURL(bundle.getString("jdbc.url"));
//			oracledataSoruce.setUser(bundle.getString("jdbc.username"));
//			oracledataSoruce.setPassword(bundle.getString("jdbc.password"));
//			con = oracledataSoruce.getConnection();

			// mysql
			Class.forName(bundle.getString("jdbc.driverClassName"));
			con = DriverManager.getConnection(bundle.getString("jdbc.url"), bundle.getString("jdbc.username"),
					bundle.getString("jdbc.password"));
		} catch (SQLException | ClassNotFoundException e) {
			log.error("Database Connection Creation Failed : ", e);
		}
	}

	public Connection getConnection() {
		return con;
	}

	public static DBConnect getInstance() {
		try {
			if (instance == null) {
				instance = new DBConnect();
			} else if (instance.getConnection().isClosed()) {
				instance = new DBConnect();
			}
		} catch (SQLException e) {
			log.error("Exception while getting connection : ", e);
		}
		return instance;
	}

	public ResultSet query(String query) {
		ResultSet res = null;
		try {
			statement = con.createStatement();
			res = statement.executeQuery(query);
		} catch (SQLException e) {
			log.error("Exception while getting resultset: ", e);
		}

		return res;
	}

	public int InsertUpdateOrDelete(String insertQuery) {
		int result = 0;
		try {
			statement = con.createStatement();
			result = statement.executeUpdate(insertQuery);
		} catch (SQLException e) {
			log.error("Exception while executeUpdate for query statement: ", e);
		}
		return result;
	}

	public int InsertUpdateOrDelete(PreparedStatement pstatement) {
		int result = 0;
		try {
			result = pstatement.executeUpdate();
		} catch (SQLException e) {
			log.error("Exception while executeUpdate for preparedStatement: ", e);
		}
		return result;
	}
}
