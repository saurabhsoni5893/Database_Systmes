package com.ecomm.manage.app.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecomm.manage.app.model.Product;
import com.ecomm.manage.app.model.Warehouse;
import com.ecomm.manage.app.services.ProductService;
import com.ecomm.manage.app.services.ProductServiceImpl;
import com.ecomm.manage.app.services.WarehouseService;
import com.ecomm.manage.app.services.WarehouseServiceImpl;
import com.google.gson.Gson;

public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String task = req.getParameter("task");

		ProductService productService = new ProductServiceImpl();
		int success = 0;
		resp.setContentType("application/json");
		Gson gson = new Gson();

		if ("delete".equals(task)) {
			String productId = req.getParameter("productId") == null ? "" : req.getParameter("productId");

			success = productService.deleteProductById(productId);
			if (success > 0) {
				resp.getWriter().write("{\"success\":true,\"message\":\"Product successfully deleted.\"}");
			} else {
				resp.getWriter().write("{\"success\":false,\"message\":\"Something went wrong, try again!\"}");
			}
		} else if ("warehouses".equals(task)) {
			WarehouseService warehouseService = new WarehouseServiceImpl();
			List<Warehouse> warehouseList = warehouseService.getWarehouses();
			resp.getWriter().write(gson.toJson(warehouseList));
		} else {
			int warehouseId = Integer
					.parseInt(req.getParameter("warehouseId") == null ? "0" : req.getParameter("warehouseId"));
			if (warehouseId > 0) {
				List<Product> productList = productService.getProductsByWarehouseId(warehouseId);
				resp.getWriter().write(gson.toJson(productList));
			} else {
				List<Product> productList = productService.getProducts();
				resp.getWriter().write(gson.toJson(productList));
			}
		}
	}
}