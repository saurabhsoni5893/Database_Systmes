package com.ecomm.manage.app.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecomm.manage.app.model.Supplier;
import com.ecomm.manage.app.services.SupplierService;
import com.ecomm.manage.app.services.SupplierServiceImpl;
import com.google.gson.Gson;

public class SupplierController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		SupplierService supplierService = new SupplierServiceImpl();
		resp.setContentType("application/json");

		String types = req.getParameter("types");
		if ("\"All\"".equals(types)) {
			List<Supplier> supplierList = supplierService.getSuppliers();
			resp.getWriter().write(new Gson().toJson(supplierList));
		} else {
			List<Supplier> supplierList = supplierService.getSuppliersByType(types);
			resp.getWriter().write(new Gson().toJson(supplierList));
		}
	}
}
