package com.ecomm.manage.app.model;

import java.io.Serializable;

public class Product implements Serializable {

	private static final long serialVersionUID = 1L;

	String productId;
	String name;
	String type;
	int warehouseId;

	// reports
	long totalProductSold;
	long totalRevenuePerProduct;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(int warehouseId) {
		this.warehouseId = warehouseId;
	}

	public long getTotalProductSold() {
		return totalProductSold;
	}

	public void setTotalProductSold(long totalProductSold) {
		this.totalProductSold = totalProductSold;
	}

	public long getTotalRevenuePerProduct() {
		return totalRevenuePerProduct;
	}

	public void setTotalRevenuePerProduct(long totalRevenuePerProduct) {
		this.totalRevenuePerProduct = totalRevenuePerProduct;
	}

}
