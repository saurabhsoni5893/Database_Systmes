package com.ecomm.manage.app.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ecomm.manage.app.model.Product;
import com.ecomm.manage.app.singleton.connection.DBConnect;

public class ProductDAOImpl implements ProductDAO {
	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(ProductDAOImpl.class.getName());

	@Override
	public List<Product> getProducts() {
		List<Product> productList = new ArrayList<Product>();
		ResultSet rs = DBConnect.getInstance().query("Select * from F18_23_PRODUCTS");
		if (rs != null) {
			try {
				while (rs.next()) {
					Product product = new Product();
					product.setWarehouseId(rs.getInt("WAREHOUSE_ID"));
					product.setName(rs.getString("NAME"));
					product.setType(rs.getString("TYPE"));
					product.setProductId(rs.getString("PRODUCT_ID"));

					productList.add(product);
				}
			} catch (SQLException e) {
				log.error("Exception while getting product list: ", e);
			}
		}
		return productList;
	}

	@Override
	public int deleteProductById(String productId) {
		return DBConnect.getInstance()
				.InsertUpdateOrDelete("delete from F18_23_PRODUCTS where PRODUCT_ID=" + productId);
	}

	@Override
	public List<Product> getProductsByWarehouseId(int warehouseId) {
		List<Product> productList = new ArrayList<Product>();
		ResultSet rs = DBConnect.getInstance().query("Select * from F18_23_PRODUCTS where WAREHOUSE_ID=" + warehouseId);
		if (rs != null) {
			try {
				while (rs.next()) {
					Product product = new Product();
					product.setWarehouseId(rs.getInt("WAREHOUSE_ID"));
					product.setName(rs.getString("NAME"));
					product.setType(rs.getString("TYPE"));
					product.setProductId(rs.getString("PRODUCT_ID"));

					productList.add(product);
				}
			} catch (SQLException e) {
				log.error("Exception while getting product list for warehouseId: " + warehouseId, e);
			}
		}
		return productList;
	}

	@Override
	public List<Product> findProductsSoldTheMost(String startDate, String endDate) {
		String query = "SELECT NAME, SUM(QUANTITY) AS TOTAL_PRODUCT_SOLD, SUM(RATE) AS TOTAL_REVENUE_PER_PRODUCT "
				+ "FROM F18_23_PRODUCTS INNER JOIN F18_23_BUY_RETURN "
				+ "ON F18_23_PRODUCTS.PRODUCT_ID = F18_23_BUY_RETURN.PRODUCT_ID "
				+ "WHERE (F18_23_BUY_RETURN.PURCHASE_DATE BETWEEN '" + startDate + "' " + "AND '" + endDate
				+ "') AND STATUS = 'BUY' GROUP BY F18_23_PRODUCTS.NAME "
				+ "ORDER BY TOTAL_REVENUE_PER_PRODUCT DESC, TOTAL_PRODUCT_SOLD DESC LIMIT 10";

		List<Product> productList = new ArrayList<Product>();
		ResultSet rs = DBConnect.getInstance().query(query);
		if (rs != null) {
			try {
				while (rs.next()) {
					Product product = new Product();
					product.setName(rs.getString("NAME"));
					product.setTotalProductSold(rs.getLong("TOTAL_PRODUCT_SOLD"));
					product.setTotalRevenuePerProduct(rs.getLong("TOTAL_REVENUE_PER_PRODUCT"));

					productList.add(product);
				}
			} catch (SQLException e) {
				log.error("Exception while getting products sold the most: ", e);
			}
		}
		return productList;
	}

	@Override
	public List<Product> findProductsSoldTheLeast(String startDate, String endDate) {
		String query = "SELECT NAME, SUM(QUANTITY) AS TOTAL_PRODUCT_SOLD, SUM(RATE) AS TOTAL_REVENUE_PER_PRODUCT "
				+ "FROM F18_23_PRODUCTS INNER JOIN F18_23_BUY_RETURN "
				+ "ON F18_23_PRODUCTS.PRODUCT_ID = F18_23_BUY_RETURN.PRODUCT_ID "
				+ "WHERE (F18_23_BUY_RETURN.PURCHASE_DATE BETWEEN '" + startDate + "' " + "AND '" + endDate
				+ "') AND STATUS = 'BUY' GROUP BY F18_23_PRODUCTS.NAME "
				+ "ORDER BY TOTAL_REVENUE_PER_PRODUCT, TOTAL_PRODUCT_SOLD LIMIT 10";

		List<Product> productList = new ArrayList<Product>();
		ResultSet rs = DBConnect.getInstance().query(query);
		if (rs != null) {
			try {
				while (rs.next()) {
					Product product = new Product();
					product.setName(rs.getString("NAME"));
					product.setTotalProductSold(rs.getLong("TOTAL_PRODUCT_SOLD"));
					product.setTotalRevenuePerProduct(rs.getLong("TOTAL_REVENUE_PER_PRODUCT"));

					productList.add(product);
				}
			} catch (SQLException e) {
				log.error("Exception while getting products sold the most: ", e);
			}
		}
		return productList;
	}

	@Override
	public List<Product> findProductsReturnedTheMost(String startDate, String endDate) {
		String query = "SELECT NAME, SUM(QUANTITY) AS TOTAL_PRODUCT_SOLD, SUM(RATE) AS TOTAL_REVENUE_PER_PRODUCT "
				+ "FROM F18_23_PRODUCTS INNER JOIN F18_23_BUY_RETURN "
				+ "ON F18_23_PRODUCTS.PRODUCT_ID = F18_23_BUY_RETURN.PRODUCT_ID "
				+ "WHERE (F18_23_BUY_RETURN.PURCHASE_DATE BETWEEN '" + startDate + "' " + "AND '" + endDate
				+ "') AND STATUS = 'RETURN' GROUP BY F18_23_PRODUCTS.NAME "
				+ "ORDER BY TOTAL_REVENUE_PER_PRODUCT DESC, TOTAL_PRODUCT_SOLD DESC LIMIT 10";

		List<Product> productList = new ArrayList<Product>();
		ResultSet rs = DBConnect.getInstance().query(query);
		if (rs != null) {
			try {
				while (rs.next()) {
					Product product = new Product();
					product.setName(rs.getString("NAME"));
					product.setTotalProductSold(rs.getLong("TOTAL_PRODUCT_SOLD"));
					product.setTotalRevenuePerProduct(rs.getLong("TOTAL_REVENUE_PER_PRODUCT"));

					productList.add(product);
				}
			} catch (SQLException e) {
				log.error("Exception while getting products sold the most: ", e);
			}
		}
		return productList;
	}

	@Override
	public List<Product> findProductsReturnedTheLeast(String startDate, String endDate) {
		String query = "SELECT NAME, SUM(QUANTITY) AS TOTAL_PRODUCT_SOLD, SUM(RATE) AS TOTAL_REVENUE_PER_PRODUCT "
				+ "FROM F18_23_PRODUCTS INNER JOIN F18_23_BUY_RETURN "
				+ "ON F18_23_PRODUCTS.PRODUCT_ID = F18_23_BUY_RETURN.PRODUCT_ID "
				+ "WHERE (F18_23_BUY_RETURN.PURCHASE_DATE BETWEEN '" + startDate + "' " + "AND '" + endDate
				+ "') AND STATUS = 'RETURN' GROUP BY F18_23_PRODUCTS.NAME "
				+ "ORDER BY TOTAL_REVENUE_PER_PRODUCT, TOTAL_PRODUCT_SOLD LIMIT 10";

		List<Product> productList = new ArrayList<Product>();
		ResultSet rs = DBConnect.getInstance().query(query);
		if (rs != null) {
			try {
				while (rs.next()) {
					Product product = new Product();
					product.setName(rs.getString("NAME"));
					product.setTotalProductSold(rs.getLong("TOTAL_PRODUCT_SOLD"));
					product.setTotalRevenuePerProduct(rs.getLong("TOTAL_REVENUE_PER_PRODUCT"));

					productList.add(product);
				}
			} catch (SQLException e) {
				log.error("Exception while getting products sold the most: ", e);
			}
		}
		return productList;
	}

}
