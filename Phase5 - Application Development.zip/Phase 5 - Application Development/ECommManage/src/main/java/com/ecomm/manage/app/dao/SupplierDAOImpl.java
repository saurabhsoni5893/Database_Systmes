package com.ecomm.manage.app.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ecomm.manage.app.model.Supplier;
import com.ecomm.manage.app.singleton.connection.DBConnect;

public class SupplierDAOImpl implements SupplierDAO {
	/** The log. */
	private static final Logger log = LoggerFactory.getLogger(SupplierDAOImpl.class.getName());

	@Override
	public List<Supplier> getSuppliers() {
		List<Supplier> supplierList = new ArrayList<Supplier>();
		ResultSet rs = DBConnect.getInstance().query("Select * from F18_23_SUPPLIER");
		if (rs != null) {
			try {
				while (rs.next()) {
					Supplier supplier = new Supplier();
					supplier.setSupplierId(rs.getInt("SUPPLIER_ID"));
					supplier.setName(rs.getString("NAME"));
					supplier.setCity(rs.getString("CITY"));
					supplier.setState(rs.getString("STATE"));
					supplier.setContactPerson(rs.getString("CONTACT_PERSON"));
					supplier.setType(rs.getString("TYPE"));
					supplier.setContactNumber(rs.getString("CONTACT_NO"));

					supplierList.add(supplier);
				}
			} catch (SQLException e) {
				log.error("Exception while getting supplier list: ", e);
			}
		}
		return supplierList;
	}

	@Override
	public List<Supplier> getSuppliersByType(String types) {
		List<Supplier> supplierList = new ArrayList<Supplier>();
		ResultSet rs = DBConnect.getInstance().query("Select * from F18_23_SUPPLIER where TYPE IN (" + types + ")");
		if (rs != null) {
			try {
				while (rs.next()) {
					Supplier supplier = new Supplier();
					supplier.setSupplierId(rs.getInt("SUPPLIER_ID"));
					supplier.setName(rs.getString("NAME"));
					supplier.setCity(rs.getString("CITY"));
					supplier.setState(rs.getString("STATE"));
					supplier.setContactPerson(rs.getString("CONTACT_PERSON"));
					supplier.setType(rs.getString("TYPE"));
					supplier.setContactNumber(rs.getString("CONTACT_NO"));

					supplierList.add(supplier);
				}
			} catch (SQLException e) {
				log.error("Exception while getting supplier list: ", e);
			}
		}
		return supplierList;
	}

}
