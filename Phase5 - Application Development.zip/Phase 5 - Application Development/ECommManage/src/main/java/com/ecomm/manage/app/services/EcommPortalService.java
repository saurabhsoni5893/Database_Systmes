package com.ecomm.manage.app.services;

import java.util.List;

import com.ecomm.manage.app.model.EcommPortal;

public interface EcommPortalService {
	public int addEcommPortal(EcommPortal ecommPortal);

	public List<EcommPortal> getEcommPortals();
}
